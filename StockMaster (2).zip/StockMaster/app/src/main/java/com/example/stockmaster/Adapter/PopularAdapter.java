package com.example.stockmaster.Adapter;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.os.IBinder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.stockmaster.Activity.DetailActivity;
import com.example.stockmaster.Domain.ToolsDomain;
import com.example.stockmaster.R;
import com.example.stockmaster.databinding.ViewholderPopularBinding;

import java.util.ArrayList;

public class PopularAdapter extends RecyclerView.Adapter<PopularAdapter.ViewHolder> {
    ArrayList<ToolsDomain> tools;
    Context context;

    public PopularAdapter(ArrayList<ToolsDomain> tools) {
        this.tools = tools;
    }

    @NonNull
    @Override
    public PopularAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context  = parent.getContext();
        ViewholderPopularBinding binding=ViewholderPopularBinding.inflate(LayoutInflater.from(parent.getContext()),parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.binding.titleTxt.setText(tools.get(position).getTitle());
        holder.binding.priceTxt.setText(tools.get(position).getPrice()+" ₱/pc");

        Glide.with(context)
                .load(tools.get(position).getImagePath())
                .into(holder.binding.img);

        holder.itemView.setOnClickListener(view -> {
            Intent intent= new Intent(context, DetailActivity.class);
            intent.putExtra("object", tools.get(position));
            context.startActivity(intent);
        });

    }


    @Override
    public int getItemCount() {
        return tools.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ViewholderPopularBinding binding;
        public ViewHolder(ViewholderPopularBinding binding) {

            super(binding.getRoot());
            this.binding=binding;

        }
    }
}

